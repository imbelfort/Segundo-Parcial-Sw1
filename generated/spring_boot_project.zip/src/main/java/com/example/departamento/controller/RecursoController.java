package com.example.departamento.controller;

import com.example.departamento.model.Recurso;
import com.example.departamento.repository.RecursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/recursos") // ej. /api/customers
public class RecursoController {

    @Autowired
    private RecursoRepository recursoRepository;

    @GetMapping
    public List<Recurso> getAll() {
        return recursoRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Recurso> getById(@PathVariable Long id) {
        return recursoRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Recurso create(@RequestBody Recurso recurso) {
        return recursoRepository.save(recurso);
    }
}