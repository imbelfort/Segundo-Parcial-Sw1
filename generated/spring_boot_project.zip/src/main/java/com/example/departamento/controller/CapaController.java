package com.example.departamento.controller;

import com.example.departamento.model.Capa;
import com.example.departamento.repository.CapaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/capas") // ej. /api/customers
public class CapaController {

    @Autowired
    private CapaRepository capaRepository;

    @GetMapping
    public List<Capa> getAll() {
        return capaRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Capa> getById(@PathVariable Long id) {
        return capaRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Capa create(@RequestBody Capa capa) {
        return capaRepository.save(capa);
    }
}